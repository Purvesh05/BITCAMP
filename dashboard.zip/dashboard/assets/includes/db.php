<?php $conn = mysqli_connect("localhost","root","","sih");
if(mysqli_connect_error()){
	echo "error in connection";
}
?>