<?php
session_start();
include "../includes/db.php";
include "../includes/function.php";

?>


<!doctype html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html class="no-js" lang="">
<!--<![endif]-->

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>ESIC</title>
	<meta name="description" content="Ela Admin - HTML5 Admin Template">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<link rel="apple-touch-icon" href="https://i.imgur.com/QRAUqs9.png">
	<link rel="shortcut icon" href="https://i.imgur.com/QRAUqs9.png">

	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/normalize.css@8.0.0/normalize.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/font-awesome@4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/gh/lykmapipo/themify-icons@0.1.2/css/themify-icons.css">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/pixeden-stroke-7-icon@1.2.3/pe-icon-7-stroke/dist/pe-icon-7-stroke.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/3.2.0/css/flag-icon.min.css">
	<link rel="stylesheet" href="assets/css/cs-skin-elastic.css">
	<link rel="stylesheet" href="assets/css/style.css">
	<!-- <script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script> -->
	<link href="https://cdn.jsdelivr.net/npm/chartist@0.11.0/dist/chartist.min.css" rel="stylesheet">
	<link href="https://cdn.jsdelivr.net/npm/jqvmap@1.5.1/dist/jqvmap.min.css" rel="stylesheet">

	<link href="https://cdn.jsdelivr.net/npm/weathericons@2.1.0/css/weather-icons.css" rel="stylesheet" />
	<link href="https://cdn.jsdelivr.net/npm/fullcalendar@3.9.0/dist/fullcalendar.min.css" rel="stylesheet" />

	<style>
		#weatherWidget .currentDesc {
        color: #ffffff!important;
    }
        .traffic-chart {
            min-height: 335px;
        }
        #flotPie1  {
            height: 150px;
        }
        #flotPie1 td {
            padding:3px;
        }
        #flotPie1 table {
            top: 20px!important;
            right: -10px!important;
        }
        .chart-container {
            display: table;
            min-width: 270px ;
            text-align: left;
            padding-top: 10px;
            padding-bottom: 10px;
        }
        #flotLine5  {
             height: 105px;
        }
        #flotBarChart {
            height: 150px;
        }
        #cellPaiChart{
            height: 160px;
        }
    </style>
</head>

<body>
	<!-- Left Panel -->
	<aside id="left-panel" class="left-panel">
		<nav class="navbar navbar-expand-sm navbar-default">
			<div id="main-menu" class="main-menu collapse navbar-collapse">
				<ul class="nav navbar-nav">
                    <li>
                        <a href="index.php"><i class="menu-icon fa fa-laptop"></i>Dashboard </a>
                    </li>
                    <li>
                        <a href="firstHistory.php"><i class="menu-icon fa fa-laptop"></i>First History</a>
                    </li>
                    <li>
                        <a href="../SampleAvatar/index.php"><i class="menu-icon fa fa-laptop"></i>Treatment analysis</a>
                    </li>
                    <li class="active">
                        <a href="predict.php"><i class="menu-icon fa fa-laptop"></i>Appointment</a>
                    </li>
                    <li>
                        <a href="notify/providers.php"><i class="menu-icon fa fa-laptop"></i>Select Providers</a>
                    </li>
                    
                    <li>
                        <a href="helpline.php"><i class="menu-icon fa fa-laptop"></i>Help Line numbers</a>
                    </li>
                    <li>
                        <a href="cluster.php"><i class="menu-icon fa fa-laptop"></i>potential locations</a>
                    </li>
                    
                    <!--
                    <li>
                        <a href="request.php"><i class="menu-icon fa fa-laptop"></i>Request Medicine</a>
                    </li> -->
                </ul>
			</div><!-- /.navbar-collapse -->
		</nav>
	</aside>
	<!-- /#left-panel -->
	<!-- Right Panel -->
	<div id="right-panel" class="right-panel">
		<!-- Header-->
		<header id="header" class="header">
			<div class="top-left">
				<div class="navbar-header">
					<a class="navbar-brand" href="./"><img src="images/logo.PNG"width="350" height="50" alt="Logo"></a>
					<a class="navbar-brand hidden" href="./"><img src="images/logo2.png" alt="Logo"></a>
					<a id="menuToggle" class="menutoggle"><i class="fa fa-bars"></i></a>
				</div>
			</div>
			<div class="top-right">
				<div class="header-menu">
					

					<div class="user-area dropdown float-right">
						<a href="#" class="dropdown-toggle active" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
							<img class="user-avatar rounded-circle" src="images/admin.jpg" alt="User Avatar">
						</a>

						<div class="user-menu dropdown-menu">
							<a class="nav-link" href="#"><i class="fa fa- user"></i>My Profile</a>


							<a class="nav-link" href="#"><i class="fa fa -cog"></i>Settings</a>

							<a class="nav-link" href="#"><i class="fa fa-power -off"></i>Logout</a>
						</div>
					</div>

				</div>
			</div>
		</header>
		<!-- /#header -->
		<!-- Content -->
		<div class="content">
			<!-- Animated -->
			<div class="animated fadeIn">

				<!-- form -->
				<div class="container">
					<div class="row">
                        <h2>Appointment management portal</h2></div><br><br>
						<div class="row">
						<form action="" method="post">
							<div class="row">
							    <div class="col-lg-6">
							        <select name="month" id="month" class="form-control">
								<option value="5">May</option>
								<option value="6">June</option>
							</select>
							    </div>
							    <div class="col-lg-1">
							        <p>  </p>
							    </div>
							    <div class="col-lg-4">
							        <input type="submit" value="submit" name="submit" class="btn btn-primary">
							    </div>
							</div>
							
							
						</form>
						<?php
					
					
if(isset($_POST['submit'])){
	$_SESSION['month'] = $month = $_POST['month'];
$query = "select * from checkup_data where next_month = '$month' and admit = 0";
$result = mysqli_query($conn,$query);
	if(!$result){
		echo "not result";
	}
	
$ab = array();
while($row = mysqli_fetch_array($result)){
	 $a = $row['next_date'];
	 array_push($ab,$a);
	
}
$a = $ab;

$b = array_unique($a);

$m = sizeof($a);
$count = 0; 
$sum = 0;
foreach($b as $uk){
    for($i=0;$i<$m;$i++) {
        if($uk == $a[$i]){
			$count = $count + 1;
		}
    }
    
    $sum = $sum + ($count * $uk);
    $count = 0;
}

$ad = $sum/$m;
	$_SESSION['ad'] = ceil($ad);
$ad =  ceil($ad);
echo "<h4 style='position:relative; top:40px; left:-200px; color:red'>Best date for visit: $ad/$month/2019</h4>";     
}

?>
				 
					</div>
					<br><br>
					<div class="row">
					
						<h2>Name of the patients</h2>
						<table class="table table-striped">
							<thead>
								<tr>
									<th>Name</th>
									<th>Age</th>
									<th>Sex</th>
									<th>Examiner</th>
									<th>Dieases</th>
									
								</tr>
							</thead>
							<tbody>
							<?php 
								
				if(isset($_POST['submit'])){
				$query = "select * from `checkup_data` where `next_month` = '$month' and `admit` = 0";
				$result = mysqli_query($conn,$query);
								$max=0;
					$cnt = 0;
								while($row = mysqli_fetch_array($result)){
									
									$name = $row['patient_name'];
									$age = $row['age'];
									$gender = $row['sex'];
									$doc = $row['examiner_name'];
									$disease = $row['disease'];
									$d_required = $row['no_of_doctors'];
									echo "<tr>";
									echo "<td>$name</td>";
									echo "<td>$age</td>";
									echo "<td>$gender</td>";
									echo "<td>$doc</td>";
									echo "<td>$disease</td>";
									
									if($max<$d_required){
										$max=$d_required;
									}
									$cnt = $cnt + 1;
									$_SESSION['cnt'] =  $cnt;
								}
								
									
								
							$q="SELECT * from `doctors` where `availability`=1 ";
							$re=mysqli_query($conn,$q);
                            if(!$re){
                                die(mysqli_error($conn));
                            }
							
						    $count = mysqli_num_rows($re);						
							
				}
								
								
								
								
							?>
								
							</tbody>
							
						</table>
					</div>
					<br>
					<div class="row">
						
						<table class="table table-striped">
							<thead>
								<tr>
									<th><h2>Doctor's Available</h2></th>
									
								</tr>
							</thead>
							<tbody>
							<?php 
								if(isset($_POST['submit'])){
							$q1="SELECT `name` from `doctors` where `availability`=1 ";
							$rwe=mysqli_query($conn,$q1);
							
						    
								while($row2 = mysqli_fetch_array($rwe)){
									
									$name = $row2['name'];
									
									echo "<tr>";
									echo "<td>$name</td>";
									
								}
									$_SESSION['max'] = $max;
								$diff=$count-$max;
									
								}
								
							
								
	
							?>
								
							</tbody>
							
						</table>
					</div>
					
					
					
					<?php

if(isset($_POST['submit'])){

	
	/*
*/
$email="vikasmaurya9732@gmail.com";


		$url = "http://localhost/sih/dashboard/specid0.html?email=$email";



   require '../forgot/vendor/autoload.php';

	$mail = new PHPMailer\PHPMailer\PHPMailer();
	$mail->isSMTP();
	$mail->Host = "smtp.gmail.com";
	$mail->Port=587;
	$mail->SMTPAuth=true;
	$mail->SMTPSecure="tls";
   // $mail->SMTPDebug = 2;
    $mail->SMTPOptions = array(
    'ssl' => array(
        'verify_peer' => false,
        'verify_peer_name' => false,
        'allow_self_signed' => true
    )
);

  $mail->Username="sihnotifications@gmail.com"; //emailid
	$mail->Password="travisscott"; //password

	$mail->setfrom("sihnotifications@gmail.com","ESIC");
	$mail->addAddress($email);

	$mail->isHTML(true);

	$mail->Subject="Medicine Requirement for following:<br>$name";
	$mail->Body    = "To know more visit this link : $url";
	//$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

	if(!$mail->send()) {
    echo 'Message could not be sent.<br>';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo '<br>Message has been sent';
}
}
?>

					<?php 
				if(isset($_POST['submit'])){
					
		if ($diff<0){ 
					?>
					<form action="" method="post">
		<input type="submit" class="form-control" value="Contact Ngo for <?php echo -($diff) ?> Doctors"></form>
	<?php }}?>
				
				<?php 
					if(isset($_POST['dt'])){
						$d_name = $_POST['d_name'];
						$ad = $_SESSION['ad'];
						$month = $_SESSION['month'];
						$cnt = $_SESSION['cnt'];
						$max = $_SESSION['max'];
						
						$query = "INSERT INTO `doct` (`id`, `date`, `no_of_patient`, `no_of_doctors_req`, `doctor_name`) VALUES (NULL, '$ad/$month/2019', '$cnt', '$max', '$d_name');";
						$result = mysqli_query($conn,$query);
						if($result){
							echo "successfully added";
						}else{
							die(mysqli_error($conn));
						}
					}
					
					?>
					
				</div>
				<!-- form end -->

				<!-- /.content -->
				<div class="clearfix">
				<?php if(isset($_POST['submit'])){
    ?>
					<b>No Of Patient's Visiting : <?php echo $cnt; ?></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<b>No Of Doctors Needed : <?php echo $max; ?></b>
					<?php }?>
					<br>
					<br>
					<form action="" method="post">
					<textarea name="d_name" id="" cols="50" rows="6"></textarea>
					<br>
					<br>
					<input type="submit" name="dt" value="Assign Doctors">
					</form>
					
					
				</div>
				<!-- Footer -->
				<footer class="site-footer">
					<div class="footer-inner bg-white">
						<div class="row">
						</div>
					</div>
				</footer>
				<!-- /.site-footer -->
			</div>
		</div>
	</div>
	
	
	
	
	

	<!-- Scripts -->
	<script src="https://cdn.jsdelivr.net/npm/jquery@2.2.4/dist/jquery.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.4/dist/umd/popper.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js"></script>
	<script src="https://cdn.jsdelivr.net/npm/jquery-match-height@0.7.2/dist/jquery.matchHeight.min.js"></script>
	<script src="assets/js/main.js"></script>


</body>

</html>
