<?php 
ob_start();
session_start();
include("../includes/db.php");
include("../includes/function.php");

 if(isset($_POST['cond'])){
		
		 $cond = $_POST['cond'];
	 
$query = "SELECT * FROM `table_10` where  conditions like '%".$cond."%' limit 4";
$result = mysqli_query($conn,$query);
if(!$result){
	die(mysqli_error($conn));
}
		
while($row = mysqli_fetch_assoc($result)){
	
	$cond = $row['conditions'];
	?>
	
	<li onclick="fill('<?php echo $cond; ?>');"><a><?php echo $cond; ?></a></li>
	
	<?php
	
}		
}else{
	 echo "No diease";
 }


?>

<script>


</script>





